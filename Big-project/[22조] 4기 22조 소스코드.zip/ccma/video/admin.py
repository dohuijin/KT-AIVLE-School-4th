# video/admin.py
from django.contrib import admin